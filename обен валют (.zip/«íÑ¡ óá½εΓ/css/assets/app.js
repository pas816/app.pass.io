// Импортируем необходимые библиотеки
const TonClient = require('@tonclient/core').TonClient;
const { libNode } = require('@tonclient/lib-node');

// Инициализируем клиента
TonClient.useBinaryLibrary(libNode);
const client = new TonClient({ network: { endpoints: ['https://main.ton.dev'] } });

// Функция для подключения к кошельку
async function connectToWallet(walletAddress) {
    try {
        // Получаем информацию о кошельке
        const walletInfo = await client.net.query_collection({
            collection: 'accounts',
            filter: { id: { eq: walletAddress } },
            result: 'id, balance, last_transaction_id',
        });

        // Проверяем, существует ли кошелек
        if (walletInfo.result.length === 0) {
            throw new Error('Кошелек не найден');
        }

        console.log('Кошелек найден:', walletInfo.result[0]);
    } catch (error) {
        console.error('Ошибка подключения к кошельку:', error.message);
    }
}

// Пример использования
const walletAddress = 'Ваш_адрес_кошелька';
connectToWallet(walletAddress);
export const Header = () => {
    return (
      <header>
        <span>My App with React UI</span>
        <TonConnectButton />
      </header>
    );
  };